Writing HTML
============
version 4.5.2
June 2000

This archive contains all of the files
you will need to complete the MCLI
"Writing HTML" tutorial. 

The file "writinghtml.zip" contains over 750
files arranged in the same directory structure
as from our web server. 

Make sure that you use the appropriate unZIP
options to expand into directories ("-d" for
PKUNZIP). 

You should end up with a directory named
"writinghhtml" that contains this readme file, a
file called "start.html" and a subdirectory
named "tut" that has many more files and
directories within. 

If your directories are not structured this 
way, than it is likely that you did not set 
the proper settings in your ZIP utility to 
"expand into directories"

To get started...

Either:
(1) Doubleclick the "start.html" file.

OR

(1) Launch your web browser application
(2) From the "File" menu, select "Open..."
or "Open Local..."
(3) From the dialog box, find the file
called Start.html (it is in the same directory
as this readme file).

And there you go!

Alan Levine
webdude@jade.mcli.dist.maricopa.edu

Writing HTML
  http://www.mcli.dist.maricopa.edu/tut/
  